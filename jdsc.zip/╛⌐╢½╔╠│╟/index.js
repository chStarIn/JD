const exp = require('express');
const bodyParser = require('body-parser');
const multer = require('multer');
const cookie = require('cookie-parser');
const fs = require('fs');

const app = exp();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookie());


// *************   注册   ***************
app.post('/register', (req, res) => {
    var userName = req.body.username;
    console.log(userName);
    var filename = `user/${userName}.txt`;
    fs.exists('user', (ex) => {
        if (ex) {
            // 写入数据
            setDate();
        }
        else {
            fs.mkdir('user', (error) => {
                if (!error) {
                    // 写入数据
                    setDate();
                }
            })
        }
    })

    // 写入数据
    function setDate() {
        fs.exists(filename, (ex) => {
            if (ex) {
                res.status(200).json({
                    code: 'error',
                    msg: '用户已存在,请直接登录'
                })
            }
            else {
                fs.appendFile(filename, JSON.stringify(req.body), (error) => {
                    if (!error) {
                        res.status(200).json({
                            code: 'success',
                            msg: '用户注册成功'
                        })
                    }
                })
            }
        })
    }
})

// ***************    登录    ***************
app.post('/login', (req, res) => {
    var filename = `user/${req.body.username}.txt`;
    fs.exists(filename, (ex) => {
        if (ex) {
            var user = JSON.parse(fs.readFileSync(filename).toString());
            if (req.body.password == user.password) {
                // 用于首页账户登录使用
                var date = new Date()
                res.cookie('name', req.body.username, date.setMonth(date.getMonth() + 1));
                res.status(200).json({
                    code: 'success',
                    msg: '登录成功'
                })
            }
            else {
                res.status(200).json({
                    code: 'error',
                    msg: '密码错误'
                })
            }
        }
        else {
            res.status(200).json({
                code: 'no_error',
                msg: '用户未注册 , 请先注册'
            })
        }
    })
})
// 退出清除cookie
app.get('/cookieOut', (req, res) => {
    // 清除cookie
    res.clearCookie('name');

    // 返回响应的数据
    res.status(200).json({
        code: 'success',
        msg: '清除cookie'
    })
})

// 管线处理
function isLogin(req,res,next){
    if(req.cookies.username){
        res.clearCookie('username');
    }
    next();
}
app.get('/login.html',isLogin,(req,res,next)=>{
    next();
})

app.get('/register.html',isLogin,(req,res,next)=>{
    next();
})

app.use(exp.static('public'));
app.listen(3000, () => {
    console.log('Server opened......');
})