var findGoods = {
    "head": {
        "tit": "发现好货",
        "href": "//fxhh.jd.com/index.html",
        "atext": "\n                发现品质生活\n                \n            "
    },
    "body": [
        {
            "href": "//fxhh.jd.com/#1249364",
            "title": "斯凯奇透气健步鞋",
            "src": "//img14.360buyimg.com/mobilecms/s80x80_jfs/t10246/191/1201073977/24450/61023d85/59dd904cNf1c813d4.jpg!q90.webp"
        },
        {
            "href": "//fxhh.jd.com/#1076362",
            "title": "儿童电动机器狗",
            "src": "//img12.360buyimg.com/mobilecms/s80x80_jfs/t5719/266/6072759412/30450/e753c5cd/59677766N05938955.jpg!q90.webp"
        },
        {
            "href": "//fxhh.jd.com/#1251146",
            "title": "威龙圣堡男士休闲鞋",
            "src": "//img11.360buyimg.com/mobilecms/s80x80_jfs/t10870/44/1220372767/133240/de7203d1/59de25e4N2e999bca.png!q90.webp"
        },
        {
            "href": "//fxhh.jd.com/#1249720",
            "title": "联想独显游戏本",
            "src": "//img10.360buyimg.com/mobilecms/s80x80_jfs/t8734/72/1130157465/233216/151b3792/59b4be02Nf3ad21a1.jpg!q90.webp"
        },
        {
            "href": "//fxhh.jd.com/#1141065",
            "title": "佰草集肌活新颜套装",
            "src": "//img10.360buyimg.com/mobilecms/s80x80_jfs/t1057/152/561566137/100593/1e7d589e/55306db8N428d7e72.jpg!q90.webp"
        },
        {
            "href": "//fxhh.jd.com/#1245974",
            "title": "流苏装饰真皮水桶包",
            "src": "//img14.360buyimg.com/mobilecms/s80x80_jfs/t10813/211/1038647374/39843/7e4ff115/59db7d08N374f495a.jpg!q90.webp"
        }
    ]
}