var will_buy = {
    "head": {
        "tit": "会买专辑",
        "href": "//ypzj.jd.com/",
        "atext": "\n                甄选优质好物\n            "
    },
    "body": [
        [
            {
                "href": "//ypzj.jd.com/#724931",
                "desc": "潮流男童套装，懒妈也能搭出潮娃",
                "imgs": [
                    "//img10.360buyimg.com/mobilecms/s110x110_jfs/t6472/156/1833724887/399765/2a23ad8e/59589185Nbeee79a8.jpg",
                    "//img11.360buyimg.com/mobilecms/s110x110_jfs/t10165/151/1193530118/193301/b908d456/59dd7d10N7af6fe9d.jpg",
                    "//img12.360buyimg.com/mobilecms/s110x110_jfs/t9265/335/2707119507/146877/e4c82945/59dc8dbdNd8b36df6.jpg"
                ]
            },
            {
                "href": "//ypzj.jd.com/#717142",
                "desc": "复古方头单鞋，逛街or通勤好驾驭",
                "imgs": [
                    "//img13.360buyimg.com/mobilecms/s110x110_jfs/t8659/288/2403431990/42254/c38a517d/59ce0193N28178dda.jpg",
                    "//img14.360buyimg.com/mobilecms/s110x110_jfs/t8293/245/245813732/41564/dbb37cf8/59a3eb06N51267c7a.jpg",
                    "//img10.360buyimg.com/mobilecms/s110x110_jfs/t9028/203/1932309625/38434/4413194/59ce019bN3a1457f4.jpg"
                ]
            }
        ],
        [
            {
                "href": "//ypzj.jd.com/#726388",
                "desc": "旅行前做点功课，合理安排看世界",
                "imgs": [
                    "//img11.360buyimg.com/mobilecms/s110x110_jfs/t10201/112/1216252360/416425/2945cf29/59ddd684Nfe87e11e.jpg",
                    "//img12.360buyimg.com/mobilecms/s110x110_jfs/t9787/312/1207283924/485350/5571f1e0/59ddd688N5b102f11.jpg",
                    "//img13.360buyimg.com/mobilecms/s110x110_jfs/t10501/287/1248001123/459527/60214d4d/59ddd68dN73091df8.jpg"
                ]
            },
            {
                "href": "//ypzj.jd.com/#723681",
                "desc": "手机卡顿不能忍受，选择大内存才够流畅",
                "imgs": [
                    "//img14.360buyimg.com/mobilecms/s110x110_jfs/t7831/323/1114571012/280240/1cba85ad/599a80dbN40e3b700.jpg",
                    "//img10.360buyimg.com/mobilecms/s110x110_jfs/t6421/213/1939166128/73795/bf58700d/5959abcaNfc345c39.jpg",
                    "//img11.360buyimg.com/mobilecms/s110x110_jfs/t3265/34/4516815332/169829/9fc87635/584928e3N08a59764.jpg"
                ]
            }
        ],
        [
            {
                "href": "//ypzj.jd.com/#723688",
                "desc": "打造孩子天堂，儿童房格调大赏 ",
                "imgs": [
                    "//img12.360buyimg.com/mobilecms/s110x110_jfs/t5644/70/7389586310/280649/f53de575/59701689N8b4577dc.jpg",
                    "//img13.360buyimg.com/mobilecms/s110x110_jfs/t8284/67/1879769959/579145/968897aa/59c092fcN69877fb6.jpg",
                    "//img14.360buyimg.com/mobilecms/s110x110_jfs/t3553/312/1964417162/105624/3570ba22/5835ad16N1c37a272.jpg"
                ]
            },
            {
                "href": "//ypzj.jd.com/#724187",
                "desc": "潮流黑色数码，时尚气质再添酷雅",
                "imgs": [
                    "//img10.360buyimg.com/mobilecms/s110x110_jfs/t3790/111/137851155/107421/604b45d7/580091d8N9a69b7d1.jpg",
                    "//img11.360buyimg.com/mobilecms/s110x110_jfs/t1588/146/899135335/139135/21e0ca8/55b1a719N56084999.jpg",
                    "//img12.360buyimg.com/mobilecms/s110x110_jfs/t3064/188/1693292264/115570/e891640b/57d11bfaN2e8acade.jpg"
                ]
            }
        ]
    ]
}