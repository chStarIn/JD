var lqArr = {
    "head": {
        "title": "领券中心",
        "href": "//a.jd.com/",
        "text": "前往领券中心"
    },
    "body": [
        {
            "href": "//a.jd.com",
            "img": "//img14.360buyimg.com/n7/s140x140_jfs/t2119/335/260162897/562457/e758f968/55fbb8a6N64863ad3.jpg!q90.webp",
            "atitle": "仅可购买京东自营图书音像商品",
            "price": "16",
            "desc": "仅可购买京东自营图书音像商品",
            "limit": "消费满200元可用",
            "more": "更多好券"
        },
        {
            "href": "//a.jd.com/coupons.html?cat=10&st=2&page=1&ct=4",
            "img": "//m.360buyimg.com/babel/s140x140_jfs/t7798/106/2888161559/8591/b993447/59df5ddeNbe8707fe.jpg!q90",
            "atitle": "仅可购买自营雷达钟表商品",
            "price": "800",
            "desc": "仅可购买自营雷达钟表商品",
            "limit": "消费满8999元可用",
            "more": "更多服饰箱包券"
        },
        {
            "href": "//a.jd.com/coupons.html?cat=11&st=2&page=1&ct=4",
            "img": "//m.360buyimg.com/babel/s140x140_jfs/t10984/250/1325334856/11806/e628cd61/59df5df1Nbe4b3085.jpg!q90",
            "atitle": "仅可购买自营按摩椅部分商品",
            "price": "1000",
            "desc": "仅可购买自营按摩椅部分商品",
            "limit": "消费满10000元可用",
            "more": "更多数码家电券"
        },
        {
            "href": "//a.jd.com/coupons.html?cat=12&st=2&page=1&ct=4",
            "img": "//m.360buyimg.com/babel/s140x140_jfs/t10435/310/978195848/16574/fc1352a5/59dadd61Nca1c39e9.jpg!q90",
            "atitle": "仅可购买家具家居指定商品",
            "price": "800",
            "desc": "仅可购买家具家居指定商品",
            "limit": "消费满2999元可用",
            "more": "更多家居家纺券"
        }
    ]
}