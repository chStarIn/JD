var phang_arr = {
    "head": {
        "tit": "排行榜",
        "href": "//top.jd.com/",
        "atext": "专属你的购物指南"
    },
    "body": {
        "body_tit": [
            {
                "href": "//top.jd.com/?cateId=9863",
                "text": "床"
            },
            {
                "href": "//top.jd.com/?cateId=653",
                "text": "手机通讯"
            },
            {
                "href": "//top.jd.com/?cateId=1626",
                "text": "床品套件"
            },
            {
                "href": "//top.jd.com/?cateId=12353",
                "text": "智能家居"
            },
            {
                "href": "//top.jd.com/?cateId=13881",
                "text": "集成灶"
            }
        ],
        "body_cont": [
            [
                {
                    "href": "//top.jd.com?cateId=9863&itemId=10377460229",
                    "rank": "1",
                    "img": "//img14.360buyimg.com/mobilecms/s100x100_jfs/t9631/335/819275043/213985/2a5ddc34/59d82256N51235a47.jpg!q90.webp",
                    "name": "尊范家具 床 实木床 韩式田园床 欧式单双人床公主床 1.8米1.5米床卧室新婚床 907床+床头柜*2+床垫 1800*2000"
                },
                {
                    "href": "//top.jd.com?cateId=9863&itemId=17546884857",
                    "rank": "2",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t9715/316/666556488/391321/e2cac38b/59d62ae7N48186f0d.jpg!q90.webp",
                    "name": "执与 床 实木床双人床1.8米北欧原木真皮软靠高箱床1.5m婚床牛皮白蜡木现代简约卧室 原木色支架床 单床预售订金"
                },
                {
                    "href": "//top.jd.com?cateId=9863&itemId=15975581933",
                    "rank": "3",
                    "img": "//img13.360buyimg.com/mobilecms/s100x100_jfs/t7789/132/4026066789/697433/86d66455/59cc618bN21b7a66e.jpg!q90.webp",
                    "name": "优越空间 现代实木床高箱储物主卧床双人大床1.81.5米纯中式橡木色家具 （预付定金，付齐尾款发货） 1500*1900框架结构"
                },
                {
                    "href": "//top.jd.com?cateId=9863&itemId=11781743352",
                    "rank": "4",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t7525/101/4481585937/292422/a747e233/59d8fd9aN9f34ec65.jpg!q90.webp",
                    "name": "A家家具 布艺床 艺床可拆洗 现代简约储物床 北欧小户型主卧布床双人床 灰黑色(单床) 1.5*2米"
                },
                {
                    "href": "//top.jd.com?cateId=9863&itemId=15340976816",
                    "rank": "5",
                    "img": "//img11.360buyimg.com/mobilecms/s100x100_jfs/t10714/340/902883059/287966/3d6c55f4/59d99feeN41e8e022.jpg!q90.webp",
                    "name": "A家家具 真皮床 双人床 皮床现代简约卧室家具组合头层牛皮软靠真皮床 馨米黄 1.5*2米"
                },
                {
                    "href": "//top.jd.com?cateId=9863&itemId=17201405472",
                    "rank": "6",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t9778/75/282464031/954129/95bf621e/59cb1779Ne5782498.png!q90.webp",
                    "name": "南绒人真皮床1.8米双人婚床1.5米现代简约床主卧榻榻米欧式皮艺床家具 真皮床预售订金 付尾款发货 1800*2000"
                }
            ],
            [
                {
                    "href": "//top.jd.com?cateId=653&itemId=5475612",
                    "rank": "1",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t8953/339/1380655454/76531/286b66ae/59b857e9Nf5c37caa.jpg!q90.webp",
                    "name": "Apple iPhone 8 Plus (A1864) 256GB 银色 移动联通电信4G手机"
                },
                {
                    "href": "//top.jd.com?cateId=653&itemId=2385669",
                    "rank": "2",
                    "img": "//img14.360buyimg.com/mobilecms/s100x100_jfs/t2101/332/1682899980/147266/37911157/56d51a79Ned116ae9.jpg!q90.webp",
                    "name": "三星 Galaxy S7 edge（G9350）4GB+32GB 钛泽银 移动联通电信4G手机 双卡双待"
                },
                {
                    "href": "//top.jd.com?cateId=653&itemId=3893485",
                    "rank": "3",
                    "img": "//img10.360buyimg.com/mobilecms/s100x100_jfs/t4228/95/401713222/278411/2ab62e42/58b3f670N1c989184.jpg!q90.webp",
                    "name": "华为 HUAWEI P10 Plus 6GB+64GB 玫瑰金 移动联通电信4G手机 双卡双待"
                },
                {
                    "href": "//top.jd.com?cateId=653&itemId=3553539",
                    "rank": "4",
                    "img": "//img14.360buyimg.com/mobilecms/s100x100_jfs/t6421/70/1565871119/386602/6b228dc1/5954745bNc8080fc7.jpg!q90.webp",
                    "name": "小米 红米 4A 全网通 2GB内存 16GB ROM 香槟金色 移动联通电信4G手机 双卡双待"
                },
                {
                    "href": "//top.jd.com?cateId=653&itemId=3133851",
                    "rank": "5",
                    "img": "//img11.360buyimg.com/mobilecms/s100x100_jfs/t3247/351/1641651176/105164/cba8c634/57d11b9dN5f19e6bd.jpg!q90.webp",
                    "name": "Apple iPhone 7 Plus (A1661) 128G 金色 移动联通电信4G手机"
                },
                {
                    "href": "//top.jd.com?cateId=653&itemId=3893491",
                    "rank": "6",
                    "img": "//img11.360buyimg.com/mobilecms/s100x100_jfs/t4144/167/406794451/272093/a92c29bb/58b3f4f1N4f0f43b0.jpg!q90.webp",
                    "name": "华为 HUAWEI P10 全网通 4GB+64GB 玫瑰金 移动联通电信4G手机 双卡双待"
                }
            ],
            [
                {
                    "href": "//top.jd.com?cateId=1626&itemId=1492724829",
                    "rank": "1",
                    "img": "//img14.360buyimg.com/mobilecms/s100x100_jfs/t6319/127/2055894201/292607/7f121b29/595cb74fN7945de47.jpg!q90.webp",
                    "name": "南极人四件套纯棉床上用品全棉床品套件1.5-1.8米床适用(被套2X2.3米) 航海日记/经典花色"
                },
                {
                    "href": "//top.jd.com?cateId=1626&itemId=756943",
                    "rank": "2",
                    "img": "//img13.360buyimg.com/mobilecms/s100x100_jfs/t4558/306/792184947/115011/6104d486/58d483f1Ne39a9316.jpg!q90.webp",
                    "name": "LOVO 罗莱生活出品 全棉斜纹四件套双人加大床吉诺220*240cm"
                },
                {
                    "href": "//top.jd.com?cateId=1626&itemId=10357657277",
                    "rank": "3",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t3937/231/87953839/565527/3c2d6137/583bd349Nc563ec92.jpg!q90.webp",
                    "name": "南极人四件套纯棉床上用品斜纹全棉活性印花被套床单式床品套件1.5-1.8米床通用 比利亚庄园 1.8m(6英尺)"
                },
                {
                    "href": "//top.jd.com?cateId=1626&itemId=4980711",
                    "rank": "4",
                    "img": "//img11.360buyimg.com/mobilecms/s100x100_jfs/t9151/253/2516406366/165832/3c3646db/59cf6783N16be17bd.jpg!q90.webp",
                    "name": "水星家纺 床上四件套 欧式大提花床品套件 被套床单被罩床上用品 英伦时光 加大双人1.8米床"
                },
                {
                    "href": "//top.jd.com?cateId=1626&itemId=3176517",
                    "rank": "5",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t3199/27/1562389849/114012/437a59a7/57cfd81bN462c958c.jpg!q90.webp",
                    "name": "南极人家纺 套件高支高密被套床单全棉床上用品斜纹印花双人四件套 裸婚时代 1.5/1.8米床 被套200x230cm"
                },
                {
                    "href": "//top.jd.com?cateId=1626&itemId=10489264012",
                    "rank": "6",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t3100/167/2731576896/412836/ea543261/57e52011N97ac7286.jpg!q90.webp",
                    "name": "北极绒 全棉斜纹纯色四件套 高支高密床品套件 爱巢 标准号200*230cm"
                }
            ],
            [
                {
                    "href": "//top.jd.com?cateId=12353&itemId=3304325",
                    "rank": "1",
                    "img": "//img10.360buyimg.com/mobilecms/s100x100_jfs/t3799/69/600155193/86695/855657f/580f2cdcN5facc835.jpg!q90.webp",
                    "name": "小米（MI）米兔智能故事机儿童早教机Wifi 微信远程互动 男孩女孩0-6岁宝宝婴儿幼儿 益智玩具学习机"
                },
                {
                    "href": "//top.jd.com?cateId=12353&itemId=4026900",
                    "rank": "2",
                    "img": "//img10.360buyimg.com/mobilecms/s100x100_jfs/t3661/28/911308875/198982/dfeea652/58174107Nb1134e83.jpg!q90.webp",
                    "name": "米家（MIJIA）小米空气净化器pro 家用卧室静音智能抗菌除甲醛雾霾粉尘PM2.5 霾表屏幕显示"
                },
                {
                    "href": "//top.jd.com?cateId=12353&itemId=5142863",
                    "rank": "3",
                    "img": "//img13.360buyimg.com/mobilecms/s100x100_jfs/t8224/220/1789008504/47473/f5e2b05d/59bf2bd1N86fbb345.jpg!q90.webp",
                    "name": "小蚁（YI）智能摄像机 1080P高清 增强红外夜视摄像机 室外防水防尘网络监控摄像头 室外机监控 智能家居"
                },
                {
                    "href": "//top.jd.com?cateId=12353&itemId=3252760",
                    "rank": "4",
                    "img": "//img10.360buyimg.com/mobilecms/s100x100_jfs/t2830/108/3698779685/84353/363c3fba/5795ce72N6b9c11f6.jpg!q90.webp",
                    "name": "乔安（JOOAN）4.5米延长线 220V电源延长线 无线网络监控摄像头加长电源线"
                },
                {
                    "href": "//top.jd.com?cateId=12353&itemId=4844146",
                    "rank": "5",
                    "img": "//img11.360buyimg.com/mobilecms/s100x100_jfs/t4756/55/1077560982/50708/dc88e358/58ec8ec5N91675a8a.jpg!q90.webp",
                    "name": "小方智能摄像机 小米（MI）无线wifi摄像头网络家用监控摄像头高清 红外夜视1080P 智能家居"
                },
                {
                    "href": "//top.jd.com?cateId=12353&itemId=3498166",
                    "rank": "6",
                    "img": "//img11.360buyimg.com/mobilecms/s100x100_jfs/t2881/331/4344253466/100768/5fe6ed8d/57b5741eN27b9c1e2.jpg!q90.webp",
                    "name": "萤石（EZVIZ）C6H经典款云台摄像头 360°全景网络摄像头 智能家居 高清监控摄像机 海康威视旗下品牌"
                }
            ],
            [
                {
                    "href": "//top.jd.com?cateId=13881&itemId=1610911552",
                    "rank": "1",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t5638/342/8192426841/469148/7d796f37/59783d95Nce4d70cc.jpg!q90.webp",
                    "name": "欧恒（OUHENG）集成灶 侧吸油烟机 燃气灶消毒柜 一体机环保灶具套装 自动清洗A8 A8-1000黑色 双电机 天然气"
                },
                {
                    "href": "//top.jd.com?cateId=13881&itemId=12422023185",
                    "rank": "2",
                    "img": "//img10.360buyimg.com/mobilecms/s100x100_jfs/t9661/62/1199556957/243546/9ca2df7d/59dde805N78fe5de5.jpg!q90.webp",
                    "name": "贵度（GUIDU）集成灶小户型侧吸下排式油烟机燃气灶消毒柜套装 分体式集成灶具节能灶一体灶 75A小户型+宽750MM+节能猛火 管道天然气（12T）"
                },
                {
                    "href": "//top.jd.com?cateId=13881&itemId=10678445216",
                    "rank": "3",
                    "img": "//img11.360buyimg.com/mobilecms/s100x100_jfs/t9523/215/42069848/143961/9f0aeb12/59c45afbNa99500dd.jpg!q90.webp",
                    "name": "TCL 集成灶 侧吸式环保灶 自动清洗抽油烟机灶具消毒柜套装 集成灶具 JC21(双电机智能清洗豪华款) 天然气"
                },
                {
                    "href": "//top.jd.com?cateId=13881&itemId=10610617616",
                    "rank": "4",
                    "img": "//img11.360buyimg.com/mobilecms/s100x100_jfs/t10678/266/198122202/160252/bc54638d/59c8b8b0N71c29e47.jpg!q90.webp",
                    "name": "贵度（GUIDU）集成灶侧吸下排式油烟机燃气灶消毒柜套装 分体式集成灶具节能灶一体灶苹果机 YH3S升级款+宽900MM+云弧控烟 管道天然气（12T）"
                },
                {
                    "href": "//top.jd.com?cateId=13881&itemId=11727321242",
                    "rank": "5",
                    "img": "//img12.360buyimg.com/mobilecms/s100x100_jfs/t6178/148/1965923556/164079/6adb3a2c/595b3ccaN78d1d040.jpg!q90.webp",
                    "name": "蓝炬星lajoson集成灶D5 自动清洗抽油烟机灶具消毒柜套装天然气 侧吸式 环保灶 燃气灶+燃气灶 天然气"
                },
                {
                    "href": "//top.jd.com?cateId=13881&itemId=11616261328",
                    "rank": "6",
                    "img": "//img13.360buyimg.com/mobilecms/s100x100_jfs/t10102/243/985478020/380455/2a7b90f5/59db2ddcNf62e6a10.jpg!q90.webp",
                    "name": "欧门 集成灶 烟灶消套装侧吸式集成环保灶 X9 经典款（智能清洗） 天然气"
                }
            ]
        ]
    }
}